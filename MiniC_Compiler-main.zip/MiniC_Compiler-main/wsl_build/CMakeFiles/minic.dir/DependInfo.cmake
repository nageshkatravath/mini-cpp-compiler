
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/codegen/codegen.cpp" "CMakeFiles/minic.dir/src/codegen/codegen.cpp.o" "gcc" "CMakeFiles/minic.dir/src/codegen/codegen.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/codegen/reg_alloc.cpp" "CMakeFiles/minic.dir/src/codegen/reg_alloc.cpp.o" "gcc" "CMakeFiles/minic.dir/src/codegen/reg_alloc.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/codegen/x86_emitter.cpp" "CMakeFiles/minic.dir/src/codegen/x86_emitter.cpp.o" "gcc" "CMakeFiles/minic.dir/src/codegen/x86_emitter.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/common/error.cpp" "CMakeFiles/minic.dir/src/common/error.cpp.o" "gcc" "CMakeFiles/minic.dir/src/common/error.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/debug/dwarf_emitter.cpp" "CMakeFiles/minic.dir/src/debug/dwarf_emitter.cpp.o" "gcc" "CMakeFiles/minic.dir/src/debug/dwarf_emitter.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/debug/source_map.cpp" "CMakeFiles/minic.dir/src/debug/source_map.cpp.o" "gcc" "CMakeFiles/minic.dir/src/debug/source_map.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/ir/cfg.cpp" "CMakeFiles/minic.dir/src/ir/cfg.cpp.o" "gcc" "CMakeFiles/minic.dir/src/ir/cfg.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/ir/ir_gen.cpp" "CMakeFiles/minic.dir/src/ir/ir_gen.cpp.o" "gcc" "CMakeFiles/minic.dir/src/ir/ir_gen.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/ir/ir_printer.cpp" "CMakeFiles/minic.dir/src/ir/ir_printer.cpp.o" "gcc" "CMakeFiles/minic.dir/src/ir/ir_printer.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/ir/tac.cpp" "CMakeFiles/minic.dir/src/ir/tac.cpp.o" "gcc" "CMakeFiles/minic.dir/src/ir/tac.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/lexer/lexer.cpp" "CMakeFiles/minic.dir/src/lexer/lexer.cpp.o" "gcc" "CMakeFiles/minic.dir/src/lexer/lexer.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/linker/link_helper.cpp" "CMakeFiles/minic.dir/src/linker/link_helper.cpp.o" "gcc" "CMakeFiles/minic.dir/src/linker/link_helper.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/linker/symbol_resolver.cpp" "CMakeFiles/minic.dir/src/linker/symbol_resolver.cpp.o" "gcc" "CMakeFiles/minic.dir/src/linker/symbol_resolver.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/main.cpp" "CMakeFiles/minic.dir/src/main.cpp.o" "gcc" "CMakeFiles/minic.dir/src/main.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/opt/constant_folding.cpp" "CMakeFiles/minic.dir/src/opt/constant_folding.cpp.o" "gcc" "CMakeFiles/minic.dir/src/opt/constant_folding.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/opt/copy_propagation.cpp" "CMakeFiles/minic.dir/src/opt/copy_propagation.cpp.o" "gcc" "CMakeFiles/minic.dir/src/opt/copy_propagation.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/opt/dead_code_elim.cpp" "CMakeFiles/minic.dir/src/opt/dead_code_elim.cpp.o" "gcc" "CMakeFiles/minic.dir/src/opt/dead_code_elim.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/parser/ast_printer.cpp" "CMakeFiles/minic.dir/src/parser/ast_printer.cpp.o" "gcc" "CMakeFiles/minic.dir/src/parser/ast_printer.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/parser/parser.cpp" "CMakeFiles/minic.dir/src/parser/parser.cpp.o" "gcc" "CMakeFiles/minic.dir/src/parser/parser.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/sema/sema.cpp" "CMakeFiles/minic.dir/src/sema/sema.cpp.o" "gcc" "CMakeFiles/minic.dir/src/sema/sema.cpp.o.d"
  "/mnt/c/Users/Manas/OneDrive/Desktop/MiniC_Compiler/src/sema/symbol_table.cpp" "CMakeFiles/minic.dir/src/sema/symbol_table.cpp.o" "gcc" "CMakeFiles/minic.dir/src/sema/symbol_table.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
