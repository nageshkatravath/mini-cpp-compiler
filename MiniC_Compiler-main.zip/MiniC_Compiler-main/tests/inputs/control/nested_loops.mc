int main() {
    int sum = 0;
    for (int i = 0; i < 5; i = i + 1) {
        for (int j = 0; j < 5; j = j + 1) {
            sum = sum + 1;
        }
    }
    printf("%d\n", sum);
    return 0;
}
