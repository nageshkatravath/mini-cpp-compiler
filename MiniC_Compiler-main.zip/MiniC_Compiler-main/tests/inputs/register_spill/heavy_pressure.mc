int main() {
    int a1 = 1; int a2 = 2; int a3 = 3; int a4 = 4;
    int a5 = 5; int a6 = 6; int a7 = 7; int a8 = 8;
    int a9 = 9; int a10 = 10; int a11 = 11; int a12 = 12;
    int a13 = 13; int a14 = 14; int a15 = 15; int a16 = 16;
    int a17 = 17; int a18 = 18; int a19 = 19; int a20 = 20;
    // Big expression with all live
    int x = a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10;
    int y = a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20;
    printf("%d\n", x + y);
    return 0;
}
